package zzh.ui;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.content.Intent;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.text.SimpleDateFormat;
import java.util.Locale;
import android.graphics.Color;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.widget.EditText;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.concurrent.Executors;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import zzhblur.com.blurview.BlurAlgorithm;
import zzhblur.com.blurview.BlurView;
import zzhblur.com.blurview.RenderEffectBlur;
import zzhblur.com.blurview.RenderScriptBlur;
import android.view.animation.ScaleAnimation;
import android.content.Context;
import android.widget.LinearLayout;
import android.widget.*;
import android.graphics.drawable.*;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import java.io.File;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.VideoView;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.Environment;
import androidx.fragment.app.Fragment;
import zzh.source.hl2.DirchActivity;
import zzh.source.hl2.R;
import java.util.concurrent.Executors;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Locale;
import android.graphics.Color;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.widget.EditText;
import java.io.BufferedReader;

public class OptionsActivity extends Fragment {
  public static String PKG_NAME;
  public static boolean can_write = true;
  static EditText cmdArgs, GamePath = null, EnvEdit, res_width, res_height;
  public SharedPreferences mPref;
  public static String srcengDir = null;
  private static final int REQUEST_CODE_DIRCH_ACTIVITY = 1001;
  private View editTextLog;
  private View textViewLog;
  private EditText editLog;

  public static String getDefaultDir() {
    /*
    调用 getDefaultDir() 方法来获取外部存储目录路径。
    在外部存储目录下构造一个新的路径 /Android/data/ 加上 PKG_NAME（通常是应用的包名），并添加 /files。
    创建该路径对应的目录（如果它不存在的话）。
    返回构造出的路径。
    */
    File dir = Environment.getExternalStorageDirectory();
    if (dir == null || !dir.exists()) return "/sdcard/";
    return dir.getPath();
  }

  public static String getAndroidDataDir() {
    /*
    调用 getDefaultDir() 方法来获取外部存储目录路径。
    在外部存储目录下构造一个新的路径 /Android/data/ 加上 PKG_NAME（通常是应用的包名），并添加 /files。
    创建该路径对应的目录（如果它不存在的话）。
    返回构造出的路径
    */
    String path = getDefaultDir() + "/Android/data/" + PKG_NAME + "/files";
    File directory = new File(path);
    if (!directory.exists()) directory.mkdirs();
    return path;
  }

  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    mPref = PreferenceManager.getDefaultSharedPreferences(getContext());
  }

  @Nullable
  @Override
  public View onCreateView(
      @NonNull LayoutInflater inflater,
      @Nullable ViewGroup container,
      @Nullable Bundle savedInstanceState) {
    View view = inflater.inflate(R.layout.options_activity, container, false);

    // 需要适配的代码
    cmdArgs = view.findViewById(R.id.edit_cmdline);
    EnvEdit = view.findViewById(R.id.edit_env);
    GamePath = view.findViewById(R.id.edit_gamepath);

    cmdArgs.setText(mPref.getString("argv", "-console"));
    GamePath.setText(mPref.getString("gamepath", getDefaultDir() + "/srceng"));
    EnvEdit.setText(mPref.getString("env", "LIBGL_USEVBO=0"));

    Button setDiButton = view.findViewById(R.id.set_srcengDir);
    setDiButton.setOnClickListener(
        new View.OnClickListener() {
          @Override
          public void onClick(View v) {
            Intent intent = new Intent(getActivity(), DirchActivity.class);
            startActivityForResult(intent, REQUEST_CODE_DIRCH_ACTIVITY);
            if (getActivity() != null) {
              getActivity()
                  .overridePendingTransition(
                      R.anim.activity_fade_in_scer, R.anim.activity_fade_out_scer);
            }
          }
        });

    Button relogDirlogview = view.findViewById(R.id.log_menu_tore);
    relogDirlogview.setOnClickListener(
        new View.OnClickListener() {
          @Override
          public void onClick(View v) {
            //   button_sheel bottomSheet = new button_sheel();
            //   bottomSheet.show(getFragmentManager(), "MyBottomSheetDialogFragment");
            openLogEditor();
          }
        });
    editLog = view.findViewById(R.id.edittext_log);
    textViewLog = view.findViewById(R.id.textview_log);
    editTextLog = view.findViewById(R.id.edittext_log);

    return view;
  }

  public void updateSrcengDir(String newDir) {
    EnvEdit.setText(mPref.getString("env", "LIBGL_USEVBO=0"));
  }

  @Override
  public void onPause() {
    saveSettings(mPref.edit());
    EnvEdit.setText(mPref.getString("env", "LIBGL_USEVBO=0"));

    super.onPause();
  }

  public void saveSettings(SharedPreferences.Editor editor) {
    String argv = cmdArgs.getText().toString();
    String gamepath = GamePath.getText().toString();
    String env = EnvEdit.getText().toString();

    editor.putString("argv", argv);
    editor.putString("gamepath", gamepath);
    editor.putString("env", env);
    editor.apply(); // Use apply() instead of commit() for efficiency
  }

  @Override
  public void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    if (requestCode == REQUEST_CODE_DIRCH_ACTIVITY) {
      if (resultCode == DirchActivity.RESULT_OK) {
        GamePath.setText(srcengDir);
        saveSettings(mPref.edit());
        srcengDir = mPref.getString("gamepath", getDefaultDir() + "/srceng");
      }
    }
  }

  private void colorizeLog(String logContent, EditText editLog) {
    SpannableStringBuilder builder = new SpannableStringBuilder(logContent);
    // 红色关键词 log
    String[] keywords = {
      "error",
      "doesn't",
      "can't",
      "ERROR",
      "Error: Material",
      "Particles: Missing",
      "Can't find",
      " --- Missing Vgui material ",
      "Error! Variable",
      "Could not",
      " >>> crash report end",
      "unknown (base="
    };
    // 绿色关键词
    String[] greenKeywords = {
      "Found font:", "LoadLibrary:", "LoadLibrary: pModule:", "Loading game from", "ise"
    };
    // 警告关键词
    String[] wrnningKeywords = {
      "Compiler version:",
      "Compiler LDFLAGS:",
      "Compiler CFLAGS:", // 初始化字符串
      "prop.",
      "SDL",
      "GL_EXTENSIONS=",
      "GL_RENDERER=",
      "server.so loaded for",
      "Unknown command:",
      "Redownloading all lightmaps",
      "No caption found for",
      "java"
    };
    // 设置红色关键词
    for (String keyword : keywords) {
      int startPos = 0;
      while (true) {
        startPos = logContent.indexOf(keyword, startPos);
        if (startPos == -1) break;
        int endPos = startPos + keyword.length();
        builder.setSpan(
            new ForegroundColorSpan(Color.RED),
            startPos,
            endPos,
            Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        startPos = endPos;
      }
    }
    // 设置绿色关键词
    for (String keyword : greenKeywords) {
      int startPos = 0;
      while (true) {
        startPos = logContent.indexOf(keyword, startPos);
        if (startPos == -1) break;
        int endPos = startPos + keyword.length();
        builder.setSpan(
            new ForegroundColorSpan(Color.GREEN),
            startPos,
            endPos,
            Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        startPos = endPos;
      }
    }
    // 设置绿色关键词
    for (String keyword : wrnningKeywords) {
      int startPos = 0;
      while (true) {
        startPos = logContent.indexOf(keyword, startPos);
        if (startPos == -1) break;
        int endPos = startPos + keyword.length();
        builder.setSpan(
            new ForegroundColorSpan(Color.YELLOW),
            startPos,
            endPos,
            Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        startPos = endPos;
      }
    }
    editLog.setText(builder);
  }

  private void openLogEditor() {
    File logFile = new File(srcengDir, "engine.log");
    if (!logFile.exists()) {
      //  Log.e("LogEditor", "Log file does not exist.");
      return;
    }

    new Thread(
            new Runnable() {
              @Override
              public void run() {
                try (BufferedReader reader = new BufferedReader(new FileReader(logFile))) {
                  final StringBuilder sb = new StringBuilder();
                  String line;
                  while ((line = reader.readLine()) != null) {
                    sb.append(line).append("\n");
                  }

                  getActivity()
                      .runOnUiThread(
                          new Runnable() {
                            @Override
                            public void run() {
                              editLog.setText(sb.toString());
                              colorizeLog(sb.toString(), editLog);

                              Animation fadeIn =
                                  AnimationUtils.loadAnimation(getActivity(), R.anim.log_fade_in);
                              Animation fadeOut =
                                  AnimationUtils.loadAnimation(getActivity(), R.anim.log_fade_out);
                              fadeIn.setAnimationListener(
                                  new Animation.AnimationListener() {
                                    @Override
                                    public void onAnimationStart(Animation animation) {}

                                    @Override
                                    public void onAnimationEnd(Animation animation) {
                                      textViewLog.setVisibility(View.GONE);
                                      editTextLog.setVisibility(View.VISIBLE);
                                    }

                                    @Override
                                    public void onAnimationRepeat(Animation animation) {}
                                  });
                              textViewLog.startAnimation(fadeOut);
                              editTextLog.startAnimation(fadeIn);
                            }
                          });
                } catch (FileNotFoundException e) {
                  //     Log.e("LogEditor", "Log file not found.", e);
                } catch (IOException e) {
                  //    Log.e("LogEditor", "Error reading log file.", e);
                }
              }
            })
        .start();
  }
}
