package zzh.ui;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;
import com.google.android.material.button.MaterialButton;
import zzh.source.hl2.R;

import com.google.android.material.navigation.NavigationView;
import zzh.home_pageui.*;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import zzh.until.home_uicontrol.ViewPagerAdapterhome;
import zzh.until.home_uicontrol.*;
import android.view.MenuItem;
import zzh.until.VerticalPageTransformer;
import com.google.android.material.*;
import zzhblur.com.blurview.*;
import android.view.*;
import android.widget.*;
import android.graphics.*;
import android.graphics.drawable.*;

public class HomeActivity extends Fragment {

  private NavigationView navigationView;
  private ViewPager2 viewPager;
  private ViewPagerAdapterhome viewPagerAdapter;

  /*
  private ViewPager2 viewPager;
  private MaterialButton buttonFirstFragment;
  private MaterialButton buttonSecondFragment;
  private MaterialButton buttonthirdFragment;
    */

  @Nullable
  @Override
  public View onCreateView(
      @NonNull LayoutInflater inflater,
      @Nullable ViewGroup container,
      @Nullable Bundle savedInstanceState) {
    return inflater.inflate(R.layout.home_activity, container, false);
  }

  @Override
  public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
    super.onViewCreated(view, savedInstanceState);
    viewPager = view.findViewById(R.id.viewPager);
    /*
    buttonFirstFragment = view.findViewById(R.id.pageone);
    buttonSecondFragment = view.findViewById(R.id.pagetwo);
    buttonthirdFragment = view.findViewById(R.id.pagethree);
    ViewPagerAdapterhome adapter = new ViewPagerAdapterhome(getActivity());
    viewPager.setAdapter(adapter);
        viewPager.setPageTransformer(new VerticalPageTransformer());
    buttonFirstFragment.setOnClickListener(
        new View.OnClickListener() {
          @Override
          public void onClick(View v) {
            viewPager.setCurrentItem(0);
          }
        });

    buttonSecondFragment.setOnClickListener(
        new View.OnClickListener() {
          @Override
          public void onClick(View v) {
            viewPager.setCurrentItem(1);
          }
        });
      buttonthirdFragment.setOnClickListener(
        new View.OnClickListener() {
          @Override
          public void onClick(View v) {
            viewPager.setCurrentItem(2);
          }
        });
        */

    navigationView = view.findViewById(R.id.navigationView);
    viewPager = view.findViewById(R.id.viewPager);
    viewPager.setUserInputEnabled(false);
    /*

        BlurView blurView = view.findViewById(R.id.blurView);
    float radius = 8f; // 模糊半径

    ViewGroup rootView = (ViewGroup) getActivity().getWindow().getDecorView().findViewById(android.R.id.content);
    Drawable windowBackground = getActivity().getWindow().getDecorView().getBackground();
    blurView
        .setupWith(rootView, new RenderScriptBlur(getContext()))
        .setFrameClearDrawable(windowBackground) // 可选
        .setBlurRadius(radius);
        */
    setupViewPager();
    setupNavigationView();
  }

  private void setupViewPager() {
    viewPagerAdapter = new ViewPagerAdapterhome(requireActivity());
    viewPager.setAdapter(viewPagerAdapter);
    // Apply the custom PageTransformer
    viewPager.setPageTransformer(new VerticalPageTransformer());
  }

  private void setupNavigationView() {
    navigationView.setNavigationItemSelectedListener(
        new NavigationView.OnNavigationItemSelectedListener() {
          @Override
          public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            int settingsId = navigationView.getMenu().findItem(R.id.settings).getItemId();
            int homeId = navigationView.getMenu().findItem(R.id.home).getItemId();
            int modlistui = navigationView.getMenu().findItem(R.id.profile).getItemId();
            handleNavigationItemSelected(item.getItemId(), settingsId, homeId, modlistui);
            return true;
          }
        });
  }

  private void handleNavigationItemSelected(int itemId, int settingsId, int homeId, int modlistui) {
    Log.d("NavigationDebug", "Selected itemId: " + itemId);
    Log.d("NavigationDebug", "Settings ID: " + settingsId);
    Log.d("NavigationDebug", "Home ID: " + homeId);
    Log.d("NavigationDebug", "Modlist ID: " + modlistui);

    if (itemId == homeId) {
      Log.d("NavigationDebug", "Switching to Settings Fragment");
      viewPager.setCurrentItem(0);
    } else if (itemId == settingsId) {
      Log.d("NavigationDebug", "Switching to Home Fragment");
      viewPager.setCurrentItem(1);
    } else if (itemId == modlistui) {
      Log.d("NavigationDebug", "Switching to Modlist Fragment");
      viewPager.setCurrentItem(2);
    } else {
      Log.d("NavigationDebug", "Unknown itemId");
    }
  }
}
