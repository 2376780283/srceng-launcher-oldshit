package zzh.ui;

import android.content.pm.ShortcutInfo;
import android.os.Bundle;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.*;
import zzh.source.hl2.MainActivity;
import zzh.source.hl2.R;
import android.util.Log;
import android.Manifest.*;
import android.view.animation.OvershootInterpolator;
import androidx.cardview.widget.CardView;
import android.animation.*;
import com.google.android.material.*;
import zzhblur.com.blurview.BlurAlgorithm;
import zzhblur.com.blurview.BlurView;
import zzhblur.com.blurview.RenderEffectBlur;
import zzhblur.com.blurview.RenderScriptBlur;

import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.content.Context;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.text.SpannableString;
import android.text.style.StyleSpan;
import android.text.util.Linkify;
import android.util.Log;
import android.view.*;
import android.widget.*;
import java.io.File;
import java.io.FileFilter;
import java.util.ArrayList;
import java.util.List;
import java.util.Comparator;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.util.regex.Pattern;
import android.content.pm.PackageManager;
import zzh.source.hl2.R;
import android.widget.LinearLayout.LayoutParams;
import android.content.pm.PackageInfo;
import android.content.pm.Signature;
import java.security.MessageDigest;
import android.util.Base64;
import android.Manifest;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import zzh.source.hl2.MainActivity;
import android.view.LayoutInflater;
import android.graphics.Bitmap;
import java.util.Arrays;
import android.view.MotionEvent;
import android.view.View.OnTouchListener;
import android.util.*;
public class WebActivity extends Fragment {
  

  @Nullable
  @Override
  public View onCreateView(
      @NonNull LayoutInflater inflater,
      @Nullable ViewGroup container,
      @Nullable Bundle savedInstanceState) {
    View view = inflater.inflate(R.layout.web_activity, container, false);

    setupBlurView(view);

    return view;
  }

  private void setupBlurView(View view) {
    BlurView blurView = view.findViewById(R.id.blurView);
    float radius = 8f; // 模糊半径

    ViewGroup rootView =
        (ViewGroup) getActivity().getWindow().getDecorView().findViewById(android.R.id.content);
    Drawable windowBackground = getActivity().getWindow().getDecorView().getBackground();
    blurView
        .setupWith(rootView, new RenderScriptBlur(getContext()))
        .setFrameClearDrawable(windowBackground) // 可选
        .setBlurRadius(radius);
  }

  private void bounceAnimation(View view) {
    ObjectAnimator scaleX =
        ObjectAnimator.ofFloat(view, "scaleX", 0.8f, 1.2f, 1.0f); // 0.8 , 1.2 , 1.0
    ObjectAnimator scaleY = ObjectAnimator.ofFloat(view, "scaleY", 0.8f, 1.2f, 1.0f); // with上okay?
    scaleX.setDuration(700);
    scaleY.setDuration(700);
    AnimatorSet animatorSet = new AnimatorSet();
    animatorSet.playTogether(scaleX, scaleY);
    animatorSet.setInterpolator(new OvershootInterpolator());
    animatorSet.start();
  }
}
