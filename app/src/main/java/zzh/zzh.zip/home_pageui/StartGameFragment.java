package zzh.home_pageui;

import zzh.source.hl2.R;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import zzhblur.com.blurview.*;
import android.view.*;
import android.widget.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import zzh.until.tile.*;
import androidx.recyclerview.widget.GridLayoutManager;
import java.util.ArrayList;
import java.util.List;
// 报错后 补包
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class StartGameFragment extends Fragment {

  private static final String TAG = "StartGameFragment";
  private RecyclerView recyclerView;
  private RecyclerView.LayoutManager layoutManager;
  private TileAdapter adapter;
  private List<Tile> tileList; // 确保在类中声明

  @Nullable
  @Override
  public View onCreateView(
      @NonNull LayoutInflater inflater,
      @Nullable ViewGroup container,
      @Nullable Bundle savedInstanceState) {
    return inflater.inflate(R.layout.home_pageui_a, container, false);
  }

  @Override
  public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
    super.onViewCreated(view, savedInstanceState);
    setupRecyclerView(view);
    setupEdgeEffect(view);
     setupBlurView(view); // Uncomment if needed
  }

  private void setupRecyclerView(View view) {
    recyclerView = view.findViewById(R.id.recycler_view);
    layoutManager = new GridLayoutManager(getActivity(), 3); // 3 columns
    recyclerView.setLayoutManager(layoutManager);

    List<Tile> tileList = initializeTileList();
    adapter = new TileAdapter(tileList);
    recyclerView.setAdapter(adapter);
    adapter.setOnClickListener(this::handleTileClick);

    ItemTouchHelper itemTouchHelper = new ItemTouchHelper(createItemTouchHelperCallback());
    itemTouchHelper.attachToRecyclerView(recyclerView);
  }

  private List<Tile> initializeTileList() {
    List<Tile> tileList = new ArrayList<>();
    tileList.add(new Tile(R.drawable.halflife, getString(R.string.srceng_game_hl2)));
    tileList.add(
        new Tile(R.drawable.deck_boot_transition, getString(R.string.srceng_game_hl2ep1)));
    return tileList;
  }

  private void handleTileClick(View v) {
    int position = recyclerView.getChildLayoutPosition(v);
    Tile clickedTile = adapter.getTileAt(position); // Assuming TileAdapter has this method
  
  }

  private ItemTouchHelper.Callback createItemTouchHelperCallback() {
    return new ItemTouchHelper.Callback() {
      @Override
      public int getMovementFlags(
          @NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder) {
        int dragFlags =
            ItemTouchHelper.UP
                | ItemTouchHelper.DOWN
                | ItemTouchHelper.LEFT
                | ItemTouchHelper.RIGHT;
        int swipeFlags = ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT;
        return makeMovementFlags(dragFlags, swipeFlags);
      }

      @Override
      public boolean onMove(
          @NonNull RecyclerView recyclerView,
          @NonNull RecyclerView.ViewHolder viewHolder,
          @NonNull RecyclerView.ViewHolder target) {
        int fromPosition = viewHolder.getAdapterPosition();
        int toPosition = target.getAdapterPosition();
        moveItem(fromPosition, toPosition);
        adapter.notifyItemMoved(fromPosition, toPosition);
        return true;
      }

      @Override
      public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
        int position = viewHolder.getAdapterPosition();
        
      }
      
    };
  }

  

  private void moveItem(int fromPosition, int toPosition) {
    if (adapter.getTileList() != null) {
      Tile fromTile = adapter.getTileList().get(fromPosition);
      adapter.getTileList().remove(fromPosition);
      adapter.getTileList().add(toPosition > fromPosition ? toPosition - 1 : toPosition, fromTile);
    } else {
      Log.e("StartGameFragment", "tileList is null");
    }
  }

  private void removeItem(int position) {
    if (adapter.getTileList() != null) {
      adapter.getTileList().remove(position);
    } else {
      Log.e("StartGameFragment", "tileList is null");
    }
  }

  private void setupEdgeEffect(View view) {
    recyclerView.setEdgeEffectFactory(new BounceEdgeEffectFactory());
  }

  // Uncomment if you need to set up BlurView
  
  private void setupBlurView(View view) {
      BlurView blurView = view.findViewById(R.id.blurView);
      float radius = 8f; // 模糊半径

      ViewGroup rootView = (ViewGroup) getActivity().getWindow().getDecorView().findViewById(android.R.id.content);
      Drawable windowBackground = getActivity().getWindow().getDecorView().getBackground();
      blurView
          .setupWith(rootView, new RenderScriptBlur(getContext()))
          .setFrameClearDrawable(windowBackground) // 可选
          .setBlurRadius(radius);
  }
  

  private static class BounceEdgeEffectFactory extends RecyclerView.EdgeEffectFactory {
    @NonNull
    @Override
    protected EdgeEffect createEdgeEffect(@NonNull RecyclerView view, int direction) {
      return new BounceEdgeEffect(view.getContext());
    }
  }

  private static class BounceEdgeEffect extends EdgeEffect {
    public BounceEdgeEffect(Context context) {
      super(context);
    }

    @Override
    public void onPull(float deltaDistance, float displacement) {
      super.onPull(deltaDistance, displacement);
      // 添加弹跳效果
    }

    @Override
    public void onRelease() {
      super.onRelease();
      // 添加释放效果
    }
  }
  /*
  优化点
  setupRecyclerView：集中处理 RecyclerView 的设置和适配器的初始化。
  initializeTileList：初始化 Tile 列表，减少 onViewCreated 方法的复杂度。
  handleTileClick：处理点击事件，避免在回调中直接处理逻辑。
  createItemTouchHelperCallback：创建 ItemTouchHelper 的回调，简化主方法的逻辑。
  drawSwipeIcon：提取绘制图标的逻辑，使代码更整洁。
      */

}
